import logging
from telegram import Update, InputFile
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
import os

TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
USER_ID = 214241911
REPORT_PATH = "output/3t_report.xlsx"

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("你好，我係沙田賽馬智能助理！請輸入 /我要3T報表 收取最新報表。")

async def send_excel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != USER_ID:
        await update.message.reply_text("你未有權限使用此功能")
        return
    if not os.path.exists(REPORT_PATH):
        await update.message.reply_text("未找到報表，請稍後再試")
        return
    await update.message.reply_document(document=InputFile(REPORT_PATH))

app = ApplicationBuilder().token(TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(CommandHandler("我要3T報表", send_excel))
app.run_polling()
